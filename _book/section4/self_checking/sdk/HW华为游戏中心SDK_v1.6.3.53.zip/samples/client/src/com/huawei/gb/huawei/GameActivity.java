package com.huawei.gb.huawei;

import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.huawei.pay.plugin.IPayHandler;
import com.android.huawei.pay.plugin.PayParameters;
import com.android.huawei.pay.util.HuaweiPayUtil;
import com.android.huawei.pay.util.Rsa;
import com.huawei.gamebox.buoy.sdk.impl.BuoyOpenSDK;
import com.huawei.gamebox.buoy.sdk.util.DebugConfig;
import com.huawei.gamebox.buoy.sdk.util.RoleInfo;

/**
 * 登录成功进入的Activity，用于继进行浮标和支付服务
 * 
 * @author h00193325
 * 
 */
public class GameActivity extends Activity implements OnClickListener
{
    
    private static final String TAG = GameActivity.class.getSimpleName();
    
    private boolean isMainPage = true;
    
    /**
     * 支付回调handler
     */
    private IPayHandler payHandler = new IPayHandler()
    {
        @Override
        public void onFinish(Map<String, String> payResp)
        {
            DebugConfig.d(TAG, "支付结束：payResp= " + payResp);
            // 处理支付结果
            String pay = "支付未成功！";
            DebugConfig.d(TAG, "支付结束，返回码： returnCode=" + payResp.get(PayParameters.returnCode));
            // 支付成功，进行验签
            if ("0".equals(payResp.get(PayParameters.returnCode)))
            {
                if ("success".equals(payResp.get(PayParameters.errMsg)))
                {
                    // 支付成功，验证信息的安全性；待验签字符串中如果有isCheckReturnCode参数且为yes，则去除isCheckReturnCode参数
                    if (payResp.containsKey("isCheckReturnCode") && "yes".equals(payResp.get("isCheckReturnCode")))
                    {
                        payResp.remove("isCheckReturnCode");
                        
                    }
                    else
                    {// 支付成功，验证信息的安全性；待验签字符串中如果没有isCheckReturnCode参数活着不为yes，则去除isCheckReturnCode和returnCode参数
                        payResp.remove("isCheckReturnCode");
                        payResp.remove(PayParameters.returnCode);
                    }
                    // 支付成功，验证信息的安全性；待验签字符串需要去除sign参数
                    String sign = payResp.remove(PayParameters.sign);
                    
                    String noSigna = HuaweiPayUtil.getSignData(payResp);
                    
                    // 使用公钥进行验签
                    boolean s = Rsa.doCheck(noSigna, sign, GlobalParam.PAY_RSA_PUBLIC);
                    
                    if (s)
                    {
                        pay = "支付成功！";
                    }
                    else
                    {
                        pay = "支付成功，但验签失败！";
                    }
                    DebugConfig.d(TAG, "支付结束：sign= " + sign + "，待验证字段：" + noSigna + "，Rsa.doChec = " + s);
                }
                else
                {
                    DebugConfig.d(TAG, "支付失败 errMsg= " + payResp.get(PayParameters.errMsg));
                }
            }
            else if ("30002".equals(payResp.get(PayParameters.returnCode)))
            {
                pay = "支付结果查询超时！";
            }
            DebugConfig.d(TAG, " 支付结果 result = " + pay);
            Toast.makeText(GameActivity.this, pay, Toast.LENGTH_SHORT).show();
            
            // 重新生成订单号，订单编号不能重复，所以使用时间的方式，CP可以根据实际情况进行修改，最长30字符
            DateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd-hh-mm-ss-SSS", Locale.US);
            String requestId = format.format(new Date());
            ((TextView)findViewById(R.id.requestId)).setText(requestId);
        }
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        
        // 绑定支付事件
        findViewById(R.id.beginbuy).setOnClickListener(this);
        // 绑定付款事件
        findViewById(R.id.paymoney).setOnClickListener(this);
        
        HashMap<String, String> role = new HashMap<String, String>();
        
        /**
         * 将用户的等级等信息保存起来，必须的参数为RoleInfo.GAME_RANK(等级)/RoleInfo.GAME_ROLE(角色名称)
         * /RoleInfo.GAME_AREA(角色所属区)/RoleInfo.GAME_SOCIATY(角色所属公会名称)
         * 全部使用String类型存放
         */
        role.put(RoleInfo.GAME_RANK, "15级");
        role.put(RoleInfo.GAME_ROLE, "猎人");
        role.put(RoleInfo.GAME_AREA, "十五区 雄霸天下");
        role.put(RoleInfo.GAME_SOCIATY, "决战天下");
        
        // 存储用户当前的角色信息
        BuoyOpenSDK.getIntance().saveRoleInfo(role, GameActivity.this);

    }
    
    @Override
    protected void onResume()
    {
        super.onResume();
        // 在界面恢复的时候又显示浮标，和onPause配合使用
        BuoyOpenSDK.getIntance().showSmallWindow(this);
        
    }
    
    /**
     * 在界面暂停的时候可以隐藏窗口
     */
    @Override
    protected void onPause()
    {
        super.onPause();
        // 在界面暂停的时候，隐藏浮标，和onResume配合使用
        BuoyOpenSDK.getIntance().hideSmallWindow(this);
        BuoyOpenSDK.getIntance().hideBigWindow(this);
        
    }
    
    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }
    
    @Override
    public void onClick(View view)
    {
        int id = view.getId();
        String requestId = null;
        isMainPage = false;
        switch (id)
        {
        // 点击开始支付按钮，把支付选项显示出来
            case R.id.beginbuy:
                DateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd-hh-mm-ss-SSS", Locale.US);
                requestId = format.format(new Date());
                ((TextView)findViewById(R.id.requestId)).setText(requestId);
                findViewById(R.id.beginbuy).setVisibility(View.GONE);
                findViewById(R.id.buytips).setVisibility(View.VISIBLE);
                findViewById(R.id.pricelinear).setVisibility(View.VISIBLE);
                findViewById(R.id.namelinear).setVisibility(View.VISIBLE);
                findViewById(R.id.desclinear).setVisibility(View.VISIBLE);
                findViewById(R.id.requestLinear).setVisibility(View.VISIBLE);
                findViewById(R.id.paymoney).setVisibility(View.VISIBLE);
                ((TextView)findViewById(R.id.itemTips)).setText(R.string.item_tips);
                findViewById(R.id.itemTips).setVisibility(View.VISIBLE);
                break;
            // 点击付款按钮
            case R.id.paymoney:
                String price = ((EditText)findViewById(R.id.productPrice)).getText().toString().trim();
                String productName = ((EditText)findViewById(R.id.productName)).getText().toString().trim();
                String productDesc = ((EditText)findViewById(R.id.productDesc)).getText().toString().trim();
                requestId = ((TextView)findViewById(R.id.requestId)).getText().toString().trim();
                
                // 价格必须精确到小数点后两位，使用正则进行匹配
                boolean priceChceckRet = Pattern.matches("^\\d+.\\d{2}$", price);
                if (!priceChceckRet)
                {
                    Toast.makeText(getApplicationContext(), "价格必填且精确到小数点后两位", Toast.LENGTH_SHORT).show();
                    return;
                }
                
                if ("".equals(productName))
                {
                    Toast.makeText(getApplicationContext(), "道具名称必填", Toast.LENGTH_SHORT).show();
                    return;
                }
                // 禁止输入：# " & / ? $ ^ *:) \ < > | , =
                else if (Pattern.matches("[#\\$\\^&*)=|\",/<>\\?:]", productName))
                {
                    Toast.makeText(getApplicationContext(), "道具名称不能存在  #$^&*)=|\",/<>\\?:", Toast.LENGTH_LONG).show();
                    return;
                }
                // 禁止输入：# " & / ? $ ^ *:) \ < > | , =
                if ("".equals(productDesc))
                {
                    Toast.makeText(getApplicationContext(), "道具描述必填", Toast.LENGTH_SHORT).show();
                    return;
                }
                // 禁止输入：# " & / ? $ ^ *:) \ < > | , =
                else if (Pattern.matches("[#\\$\\^&*)=|\",/<>\\\\?\\^:]", productDesc))
                {
                    Toast.makeText(getApplicationContext(), "道具描述不能存在  #$^&*)=|\",/<>\\?:", Toast.LENGTH_LONG).show();
                    return;
                }
                
                // 调用公共方法进行支付
                GameBoxUtil.startPay(GameActivity.this, price, productName, productDesc, requestId, payHandler);
                break;
            default:
                break;
        }
    }
    
    /**
     * 显示测试主界面
     * 
     * @return void [返回类型说明]
     * @exception throws [违例类型] [违例说明]
     * @see [类、类#方法、类#成员]
     */
    private void returnMainPage()
    {
        findViewById(R.id.beginbuy).setVisibility(View.VISIBLE);

        findViewById(R.id.buytips).setVisibility(View.GONE);
        findViewById(R.id.pricelinear).setVisibility(View.GONE);
        findViewById(R.id.namelinear).setVisibility(View.GONE);
        findViewById(R.id.desclinear).setVisibility(View.GONE);
        findViewById(R.id.requestLinear).setVisibility(View.GONE);
        findViewById(R.id.paymoney).setVisibility(View.GONE);
        findViewById(R.id.itemTips).setVisibility(View.GONE);
        
        isMainPage = true;
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if (keyCode == KeyEvent.KEYCODE_BACK)
        {
            if (isMainPage)
            {
                super.onKeyDown(keyCode, event);
            }
            else
            {
                returnMainPage();
            }

        }
        return true;
    }


}
