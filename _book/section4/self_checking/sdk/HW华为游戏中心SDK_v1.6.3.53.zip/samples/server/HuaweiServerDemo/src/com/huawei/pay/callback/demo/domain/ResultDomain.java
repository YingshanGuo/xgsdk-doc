package com.huawei.pay.callback.demo.domain;

public class ResultDomain {

	private int result;

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}
	
}
