package com.huawei.pay.callback.demo.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;

import com.huawei.pay.callback.demo.domain.ResultDomain;
import com.huawei.pay.callback.demo.util.CommonUtil;

public class CallbackDemo extends HttpServlet
{
    
    // 支付公钥，CP需要替换成自己的
    public static final String devPubKey = "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAI3XiRc0OXxWQ6SCsn+Z+FKYlfmqJpmdwdOkgF19FPj8LEOvPlp2aRZe2DztWMyaBROUriGDjOlMdSHdL1Wdt88CAwEAAQ==";
    
    /**
     * Constructor of the object.
     */
    public CallbackDemo()
    {
        super();
    }
    
    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException,
        IOException
    {
    }
    
    /**
     * 仅接受POST请求
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException,
        IOException
    {
        
        request.setCharacterEncoding("UTF-8");
        
        Map<String, Object> map = null;
        map = getValue(request);
        if (null == map)
            return;
        
        String sign = (String)map.get("sign");
        
        ResultDomain result = new ResultDomain();
        
        result.setResult(1);
        
        // 验签成功
        if (CommonUtil.rsaDoCheck(map, sign, devPubKey))
        {
            result.setResult(0);
        }
        else
        { // 验签失败
            result.setResult(1);
        }
        
        // 构造返回值，如："{\"result\":0}"
        String resultinfo = convertJsonStyle(result);
        
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        
        System.out.println("Response string : " + resultinfo);
        
        PrintWriter out = response.getWriter();
        out.print(resultinfo);
        out.close();
    }
    
    /**
     * @param request
     * @return
     *         本接口Content-Type是：application/x-www-form-urlencoded，对所有参数，会自动进行编码，接收端收到消息也会自动根据Content-Type进行解码。
     *         同时，接口中参数在发送端并没有进行单独的URLEncode (sign和extReserved、sysReserved参数除外)，所以，在接收端根据Content-Type解码后，即为原始的参数信息。
     *         但是HttpServletRequest的getParameter()方法会对指定参数执行隐含的URLDecoder.decode(),所以，相应参数中如果包含比如"%"，就会发生错误。
     *         因此，我们建议通过如下方法获取原始参数信息。
     * 
     *         注：使用如下方法必须在原始ServletRequest未被处理的情况下进行，否则无法获取到信息。比如，在Struts情况，由于struts层已经对参数进行若干处理，
     *         http中InputStream中其实已经没有信息，因此，本方法不适用。要获取原始信息，必须在原始的，未经处理的ServletRequest中进行。
     */
    public Map<String, Object> getValue(HttpServletRequest request)
    {
        
        String line = null;
        StringBuffer sb = new StringBuffer();
        try
        {
            request.setCharacterEncoding("UTF-8");
            
            InputStream stream = request.getInputStream();
            InputStreamReader isr = new InputStreamReader(stream);
            BufferedReader br = new BufferedReader(isr);
            while ((line = br.readLine()) != null)
            {
                sb.append(line).append("\r\n");
            }
            System.out.println("The original data is : " + sb.toString());
            br.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        catch (Throwable e)
        {
            e.printStackTrace();
        }
        
        String str = sb.toString();
        Map<String, Object> valueMap = new HashMap<String, Object>();
        if (null == str || "".equals(str))
        {
            return valueMap;
        }
        
        String[] valueKey = str.split("&");
        for (String temp : valueKey)
        {
            String[] single = temp.split("=");
            valueMap.put(single[0], single[1]);
        }
        
        // 接口中，如下参数sign和extReserved、sysReserved是URLEncode的，所以需要decode，其他参数直接是原始信息发送，不需要decode
        try
        {
            String sign = (String)valueMap.get("sign");
            String extReserved = (String)valueMap.get("extReserved");
            String sysReserved = (String)valueMap.get("sysReserved");
            
            if (null != sign)
            {
                sign = URLDecoder.decode(sign, "utf-8");
                valueMap.put("sign", sign);
            }
            if (null != extReserved)
            {
                extReserved = URLDecoder.decode(extReserved, "utf-8");
                valueMap.put("extReserved", extReserved);
            }
            
            if (null != sysReserved)
            {
                sysReserved = URLDecoder.decode(sysReserved, "utf-8");
                valueMap.put("sysReserved", sysReserved);
            }
            
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return valueMap;
        
    }
    
    /**
     * 将对象转换成字符串
     * 
     * @param resultMessage
     * @return
     */
    private String convertJsonStyle(Object resultMessage)
    {
        ObjectMapper mapper = new ObjectMapper();
        Writer writer = new StringWriter();
        try
        {
            if (null != resultMessage)
            {
                mapper.writeValue(writer, resultMessage);
            }
            
        }
        catch (Exception e)
        {
            
        }
        return writer.toString();
    }
    
}
